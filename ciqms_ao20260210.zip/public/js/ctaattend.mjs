// Fetch and display training records
async function loadTrainingData() {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("Failed to fetch training records");
    const data = await response.json();
    allTrainingData = data; // Store all data for filtering
    displayTrainingTable(data);
  } catch (error) {
    console.error("Error loading training data:", error);
    document.getElementById("trainingTableContainer").innerHTML =
      '<p class="error">Failed to load training data. Please refresh the page.</p>';
  }
}

// Filter training data by employee ID
function filterTrainingData(employeeId) {
  if (!employeeId || employeeId.trim() === "") {
    // Show all data if filter is empty
    displayTrainingTable(allTrainingData);
  } else {
    // Filter data by PEOPLE_ID
    const filteredData = allTrainingData.filter(
      (item) =>
        item.PEOPLE_ID && item.PEOPLE_ID.toUpperCase().includes(employeeId),
    );
    displayTrainingTable(filteredData);
  }
}
import { loadHeaderFooter, getUserValue, getApiUrl } from "./utils.mjs";

// Initialize header/footer
loadHeaderFooter();

// Configuration
let url = ""; // Will be set dynamically
let sortOrder = "asc";
let allTrainingData = []; // Store all data for filtering

document.addEventListener("DOMContentLoaded", async function () {
  // Get the dynamic API URL before loading data
  const apiUrl = await getApiUrl();
  url = `${apiUrl}/attendance`;

  setupEventListeners();
  await loadTrainingData();
});

function setupEventListeners() {
  // Add Training button
  const addTrainingBtn = document.getElementById("addTrainingBtn");
  if (addTrainingBtn) {
    addTrainingBtn.addEventListener("click", openAddTrainingDialog);
  }

  // Close button for add training dialog
  const closeAddBtn = document.getElementById("closeAddBtn");
  if (closeAddBtn) {
    closeAddBtn.addEventListener("click", () => {
      document.getElementById("addTrainingDialog").close();
    });
  }

  // Save training form
  const saveTrainingBtn = document.getElementById("saveTrainingBtn");
  if (saveTrainingBtn) {
    saveTrainingBtn.addEventListener("click", saveTraining);
  }

  // Close dialog on outside click for add training dialog
  const addTrainingDialog = document.getElementById("addTrainingDialog");
  if (addTrainingDialog) {
    addTrainingDialog.addEventListener("click", (e) => {
      if (e.target === addTrainingDialog) {
        addTrainingDialog.close();
      }
    });
  }

  // Employee ID filter
  const employeeIdFilter = document.getElementById("employeeIdFilter");
  if (employeeIdFilter) {
    employeeIdFilter.addEventListener("input", (e) => {
      filterTrainingData(e.target.value.toUpperCase());
    });
  }

  // Clear filter button
  const clearFilterBtn = document.getElementById("clearFilterBtn");
  if (clearFilterBtn) {
    clearFilterBtn.addEventListener("click", () => {
      const filterInput = document.getElementById("employeeIdFilter");
      if (filterInput) {
        filterInput.value = "";
        filterTrainingData("");
      }
    });
  }
}

function openAddTrainingDialog() {
  const dialog = document.getElementById("addTrainingDialog");
  if (dialog) {
    // Reset form and set today's date
    const form = document.getElementById("addTrainingForm");
    form.reset();

    // Set today's date as default
    const today = new Date();
    document.getElementById("DATE_TIME").value = today
      .toISOString()
      .slice(0, 10);

    dialog.showModal();
  }
}

async function saveTraining(event) {
  event.preventDefault();
  const form = document.getElementById("addTrainingForm");
  const formData = new FormData(form);

  try {
    // Get next ID from server
    const nextIdResponse = await fetch(`${url}/nextId`);
    const nextId = await nextIdResponse.json();

    // Prepare current timestamp
    const attendanceDate = new Date();
    const myRequestDate = attendanceDate
      .toISOString()
      .slice(0, 19)
      .replace("T", " ");

    try {
      // Get attendees from PEOPLE_ID textarea, split by comma, trim, and filter out blanks
      const attendeesRaw = formData.get("PEOPLE_ID") || "";
      const attendees = attendeesRaw
        .split(",")
        .map((x) => x.trim().toUpperCase())
        .filter((x) => x);
      if (attendees.length === 0) {
        alert("Please enter at least one attendee.");
        return;
      }

      // Prepare current timestamp
      const attendanceDate = new Date();
      const myRequestDate = attendanceDate
        .toISOString()
        .slice(0, 19)
        .replace("T", " ");

      // Get the original link value once (before moving)
      const originalLinkValue = formData.get("LINK") || "";
      let movedFilePath = originalLinkValue; // Will update after first record with moved path

      // Loop through attendees and submit each record
      for (let index = 0; index < attendees.length; index++) {
        const personId = attendees[index];

        // Get next ID from server for each attendee
        const nextIdResponse = await fetch(`${url}/nextId`);
        const nextId = await nextIdResponse.json();

        // Build data object
        const dataJson = {
          COURSE_ATND_ID: nextId,
          CREATED_DATE: myRequestDate,
          CREATE_BY: "TKENT",
        };

        for (let field of formData.keys()) {
          if (field === "PEOPLE_ID") {
            dataJson[field] = personId;
          } else if (field === "INSTRUCTOR") {
            dataJson[field] = formData.get(field).toUpperCase();
          } else if (field === "LINK") {
            // Use the moved file path for all records after the first
            // First record will move the file, subsequent ones use the moved path
            dataJson[field] = index === 0 ? originalLinkValue : movedFilePath;
          } else {
            dataJson[field] = formData.get(field);
          }
        }

        // Send moveFileOnFirstRecord flag so backend knows this is the first record
        dataJson.moveFileOnFirstRecord = index === 0;

        const response = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(dataJson),
        });

        if (!response.ok) {
          const errorText = await response.text();
          alert(`Failed to save training record for ${personId}: ` + errorText);
          return; // Stop processing other attendees if one fails
        }

        // Check for file move errors in the response
        const responseData = await response.json();

        // After first record, update the file path to the moved location
        if (index === 0 && responseData.movedFilePath) {
          movedFilePath = responseData.movedFilePath;
        }

        if (responseData.fileMoveError) {
          // Check if file is locked (in use)
          if (responseData.isFileLocked) {
            const retryMove = confirm(
              `Training record saved, but the file is currently open or in use:\n\n${responseData.fileMoveError}\n\nPlease close the file and click "OK" to retry moving it, or "Cancel" to skip.`,
            );

            if (retryMove) {
              // Retry the file move
              try {
                const retryResponse = await fetch(`${url}/retry-move-file`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ linkPath: dataJson.LINK }),
                });

                const retryData = await retryResponse.json();
                if (!retryData.success) {
                  alert(`Retry failed: ${retryData.error}`);
                } else {
                  alert("File moved successfully!");
                  // Update the moved file path if move was successful
                  if (index === 0 && retryData.movedFilePath) {
                    movedFilePath = retryData.movedFilePath;
                  }
                }
              } catch (retryErr) {
                alert(`Error retrying file move: ${retryErr.message}`);
              }
            }
          } else {
            // Not a file lock error, just a regular failure
            alert(
              `Training record saved, but file move failed: ${responseData.fileMoveError}. You may need to move the file manually.`,
            );
          }
        }
      }

      document.getElementById("addTrainingDialog").close();
      // await loadTrainingData(); // Reload the data (refresh commented out)
    } catch (err) {
      alert("Error saving training record: " + err);
    }
  } catch (error) {
    console.error("Error loading training data:", error);
    document.getElementById("trainingTableContainer").innerHTML =
      '<p class="error">Failed to load training data. Please refresh the page.</p>';
  }
}

function displayTrainingTable(data) {
  const container = document.getElementById("trainingTableContainer");
  if (!container) return;

  if (!data || data.length === 0) {
    container.innerHTML = "<p>No training records found.</p>";
    return;
  }

  const table = document.createElement("table");
  table.className = "data-table";

  // Create header
  const thead = document.createElement("thead");
  const headerRow = document.createElement("tr");

  const headers = [
    "ID",
    "Course ID",
    "Date",
    "Person",
    "Instructor",
    "Minutes",
    "Created By",
    "Created Date",
    "Link",
  ];

  headers.forEach((header, index) => {
    const th = document.createElement("th");
    th.textContent = header;
    th.style.cursor = "pointer";
    th.addEventListener("click", () => sortTable(index));
    headerRow.appendChild(th);
  });

  thead.appendChild(headerRow);
  table.appendChild(thead);

  // Create body
  const tbody = document.createElement("tbody");
  tbody.id = "trainingTableBody";

  data.forEach((item) => {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${item.COURSE_ATND_ID || ""}</td>
      <td>${item.COURSE_ID || ""}</td>
      <td>${item.DATE_TIME ? formatDate(item.DATE_TIME) : ""}</td>
      <td>${item.PEOPLE_ID || ""}</td>
      <td>${item.INSTRUCTOR || ""}</td>
      <td>${item.MINUTES || ""}</td>
      <td>${item.CREATE_BY || ""}</td>
      <td>${item.CREATED_DATE ? formatDate(item.CREATED_DATE) : ""}</td>
      <td>${
        item.CTA_ATTENDANCE_LINK
          ? `<a href="/training-files/${encodeURIComponent(
              item.CTA_ATTENDANCE_LINK,
            )}" target="_blank">Open File</a>`
          : ""
      }</td>
    `;

    tbody.appendChild(row);
  });

  table.appendChild(tbody);
  container.innerHTML = "";
  container.appendChild(table);
}

function formatDate(dateString) {
  if (!dateString) return "";
  const date = new Date(dateString);
  return date.toLocaleDateString();
}

function sortTable(columnIndex) {
  const tbody = document.getElementById("trainingTableBody");
  if (!tbody) return;

  const rows = Array.from(tbody.querySelectorAll("tr"));
  const headerCells = document.querySelectorAll("thead th");

  // Toggle sort order
  sortOrder = sortOrder === "asc" ? "desc" : "asc";

  rows.sort((a, b) => {
    const aVal = a.cells[columnIndex].textContent.trim();
    const bVal = b.cells[columnIndex].textContent.trim();

    // Handle numeric columns
    if (columnIndex === 0 || columnIndex === 5) {
      // ID and Minutes
      const aNum = parseFloat(aVal) || 0;
      const bNum = parseFloat(bVal) || 0;
      return sortOrder === "asc" ? aNum - bNum : bNum - aNum;
    }

    // Handle date columns
    if (columnIndex === 2 || columnIndex === 7) {
      // Date and Created Date
      const aDate = new Date(aVal) || new Date(0);
      const bDate = new Date(bVal) || new Date(0);
      return sortOrder === "asc" ? aDate - bDate : bDate - aDate;
    }

    // Handle text columns
    return sortOrder === "asc"
      ? aVal.localeCompare(bVal)
      : bVal.localeCompare(aVal);
  });

  // Clear tbody and append sorted rows
  tbody.innerHTML = "";
  rows.forEach((row) => tbody.appendChild(row));

  // Update sort indicators
  updateSortIndicators(headerCells, columnIndex);
}

function updateSortIndicators(headerCells, activeColumnIndex) {
  headerCells.forEach((th, index) => {
    // Remove existing sort indicators
    th.textContent = th.textContent.replace(/ [↑↓]$/, "");

    // Add indicator to active column
    if (index === activeColumnIndex) {
      const indicator = sortOrder === "asc" ? " ↑" : " ↓";
      th.textContent += indicator;
    }
  });
}
