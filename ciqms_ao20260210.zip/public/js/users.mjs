export default {
  "DEFAULT": "tim.kent@ci-aviation.com",
  "TKENT": "tim.kent@ci-aviation.com",
  "BOBBI": "bobbi.bush@ci-aviation.com",
  "CHARRISON": "craig@ci-aviation.com",
  "RMATSAMAS": "tim.kent@ci-aviation.com",
  "VRASMUSSEN": "victoria.r@ci-aviation.com",
  "AMIDDLETON": "alex.m@ci-aviation.com",
  "QC": "tim.kent@ci-aviation.com, bobbi.bush@ci-aviation.com, craig@ci-aviation.com",
};
