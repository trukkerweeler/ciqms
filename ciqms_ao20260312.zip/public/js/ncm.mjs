import {
  loadHeaderFooter,
  getSessionUser,
  myport,
  getDateTime,
  getApiUrl,
} from "./utils.mjs";
import {
  calculateDaysOverdue,
  createEscalationButton,
  createEscalationHistory,
} from "./escalation-utils.mjs";
loadHeaderFooter();
const apiUrl = await getApiUrl();
const user = await getSessionUser();
const test = false;

if (test) {
  // console.log('ncm.mjs');
  console.log(user);
}

// Get the project id from the url params
let queryString = window.location.search;
let urlParams = new URLSearchParams(queryString);
let iid = urlParams.get("id");

if (test) {
  console.log(iid);
}

const url = `${apiUrl}/ncm/${iid}`;

// Function to fetch subjects from the server
async function fetchSubjects() {
  try {
    const subjectsUrl = `${apiUrl}/ncm/subjects`;
    const response = await fetch(subjectsUrl, { method: "GET" });
    const subjects = await response.json();
    return subjects;
  } catch (error) {
    console.error("Error fetching subjects:", error);
    return [];
  }
}

async function fetchCauses() {
  try {
    const causesUrl = `${apiUrl}/causemaint/`;
    const response = await fetch(causesUrl, { method: "GET" });
    const causes = await response.json();
    return causes;
  } catch (error) {
    console.error("Error fetching causes:", error);
    return [];
  }
}

// Validation helper for username fields (ending with _BY or _TO)
function validateUsernameField(fieldName, fieldValue) {
  const fieldDisplayName = fieldName.replace(/-/g, " ").toLowerCase();

  // Check for spaces
  if (fieldValue.includes(" ")) {
    return {
      isValid: false,
      message: `❌ "${fieldDisplayName}"\n\nSpaces are not allowed in username fields.\n\nFormat: First initial + Last name\nExample: TKENT (T=first initial, KENT=last name)`,
    };
  }

  // Check if field is empty
  if (!fieldValue.trim()) {
    return {
      isValid: false,
      message: `❌ "${fieldDisplayName}" is required and cannot be empty.`,
    };
  }

  return { isValid: true };
}

// Validation helper for code fields (Subject, Cause, Type, etc.)
function validateCodeField(fieldName, fieldValue) {
  const fieldDisplayName = fieldName.replace(/-/g, " ").toLowerCase();

  // Check for spaces
  if (fieldValue.includes(" ")) {
    return {
      isValid: false,
      message: `❌ "${fieldDisplayName}"\n\nSpaces are not allowed in code fields.\n\nPlease check the help file or ask your manager for valid code values.`,
    };
  }

  return { isValid: true };
}

const main = document.querySelector("main");

// Function to refresh NCM data from server and re-render
async function refreshNCMData() {
  try {
    const response = await fetch(url, { method: "GET" });
    const record = await response.json();
    renderNCMDetail(record);
  } catch (error) {
    console.error("Error refreshing NCM data:", error);
    alert("Error refreshing data. Please try again.");
  }
}

// Function to render NCM detail
async function renderNCMDetail(record) {
  // Delete the child nodes of the main element
  while (main.firstChild) {
    main.removeChild(main.firstChild);
  }

  for (const key in record) {
    // console.log(record);
    for (const key in record) {
      const detailSection = document.createElement("section");
      detailSection.setAttribute("class", "section");
      detailSection.setAttribute("id", "detailSection");
      const elemRpt = document.createElement("h1");
      const elemId = document.createElement("h2");
      const detailHeading = document.createElement("h3");
      detailHeading.setAttribute("id", "detailTitle");
      detailHeading.textContent = "Detail";

      const divDetailBtns = document.createElement("div");
      divDetailBtns.setAttribute("class", "detailButtons");
      divDetailBtns.setAttribute("id", "detailButtons");

      const btnEditDetail = document.createElement("button");
      btnEditDetail.setAttribute("class", "btn");
      btnEditDetail.setAttribute("class", "btnEditNotes");
      btnEditDetail.textContent = "Edit Detail";
      btnEditDetail.setAttribute("id", "btnEditDetail");
      btnEditDetail.setAttribute("type", "submit");

      const btnTrend = document.createElement("button");
      btnTrend.setAttribute("class", "btn");
      btnTrend.setAttribute("class", "btnEditNotes");
      btnTrend.textContent = "Trend";
      btnTrend.setAttribute("id", "btnTrend");
      btnTrend.setAttribute("type", "submit");

      // divDetailBtns.appendChild(btnClose);
      divDetailBtns.appendChild(btnTrend);
      divDetailBtns.appendChild(btnEditDetail);

      const ncmDate = document.createElement("p");
      ncmDate.textContent =
        "Request Date:" + " " + record[key]["NCM_DATE"].substring(0, 10);
      ncmDate.setAttribute("class", "tbl");

      const aiClosedDate = document.createElement("p");
      if (
        record[key]["CLOSED_DATE"] === null ||
        record[key]["CLOSED_DATE"] === "" ||
        record[key]["CLOSED_DATE"].length === 0
      ) {
        aiClosedDate.textContent = "Closed Date:" + " " + "";
        if (test) {
          console.log("closed date is null");
        }
      } else {
        aiClosedDate.textContent =
          "Closed Date:" + " " + record[key]["CLOSED_DATE"].substring(0, 10);

        if (test) {
          console.log("closed date is NOT null");
          // print button status
          // console.log(btnClose.disabled);
        }
      }

      aiClosedDate.setAttribute("class", "tbl");

      const caAssTo = document.createElement("p");
      caAssTo.textContent = "Assigned To:" + " " + record[key]["ASSIGNED_TO"];
      caAssTo.setAttribute("class", "tbl");
      const reqBy = document.createElement("p");
      reqBy.textContent = "Request By:" + " " + record[key]["PEOPLE_ID"];
      reqBy.setAttribute("class", "tbl");

      const due_date = document.createElement("p");
      if (record[key]["DUE_DATE"] === null) {
        due_date.textContent = "Due date:" + " " + "";
      } else
        due_date.textContent =
          "Due date:" + " " + record[key]["DUE_DATE"].substring(0, 10);
      due_date.setAttribute("class", "tbl");

      const ncmType = document.createElement("p");
      ncmType.textContent = "Type:" + " " + record[key]["NCM_TYPE"];
      ncmType.setAttribute("class", "tbl");

      const subject = document.createElement("p");
      subject.setAttribute("class", "tbl");
      if (
        record[key]["SUBJECT"] === null ||
        record[key]["SUBJECT"] === "" ||
        record[key]["SUBJECT"] === undefined
      ) {
        subject.textContent = "Subject:" + " --";
      } else {
        subject.textContent = "Subject:" + " " + record[key]["SUBJECT"];
      }

      const cause = document.createElement("p");
      cause.setAttribute("class", "tbl");
      if (
        record[key]["CAUSE"] === null ||
        record[key]["CAUSE"] === "" ||
        record[key]["CAUSE"] === undefined
      ) {
        cause.textContent = "Cause:" + " --";
      } else {
        cause.textContent = "Cause:" + " " + record[key]["CAUSE"];
      }

      const productId = document.createElement("p");
      productId.setAttribute("class", "tbl");
      if (
        record[key]["PRODUCT_ID"] === null ||
        record[key]["PRODUCT_ID"] === "" ||
        record[key]["PRODUCT_ID"] === undefined
      ) {
        productId.textContent = "Product Id:" + "--";
      } else {
        productId.textContent = "Product Id:" + " " + record[key]["PRODUCT_ID"];
      }

      const lotNumber = document.createElement("p");
      lotNumber.setAttribute("class", "tbl");
      lotNumber.setAttribute("id", "lotNumber");
      if (
        record[key]["LOT_NUMBER"] === null ||
        record[key]["LOT_NUMBER"] === "" ||
        record[key]["LOT_NUMBER"] === undefined
      ) {
        lotNumber.textContent = "Lot Number:" + "--";
      } else {
        lotNumber.textContent = "Lot Number:" + " " + record[key]["LOT_NUMBER"];
      }

      const lotQty = document.createElement("p");
      lotQty.setAttribute("class", "tbl");
      lotQty.setAttribute("id", "lotQty");
      if (
        record[key]["LOT_SIZE"] === null ||
        record[key]["LOT_SIZE"] === "" ||
        record[key]["LOT_SIZE"] === undefined
      ) {
        lotQty.textContent = "Lot Qty:" + "";
      } else {
        lotQty.textContent = "Lot Qty:" + " " + record[key]["LOT_SIZE"];
      }

      const rmaId = document.createElement("p");
      rmaId.textContent = "RMA Id:" + " " + record[key]["USER_DEFINED_1"];
      rmaId.setAttribute("class", "tbl");
      if (
        record[key]["USER_DEFINED_1"] === null ||
        record[key]["USER_DEFINED_1"] === "" ||
        record[key]["USER_DEFINED_1"] === undefined
      ) {
        rmaId.textContent = "RMA Id:" + "--";
      } else {
        rmaId.textContent = "RMA Id:" + " " + record[key]["USER_DEFINED_1"];
      }

      const po_number = document.createElement("p");
      po_number.textContent = "PO Number:" + " " + record[key]["PO_NUMBER"];
      po_number.setAttribute("class", "tbl");
      if (
        record[key]["PO_NUMBER"] === null ||
        record[key]["PO_NUMBER"] === "" ||
        record[key]["PO_NUMBER"] === undefined
      ) {
        po_number.textContent = "PO:" + "--";
      } else {
        po_number.textContent = "PO:" + " " + record[key]["PO_NUMBER"];
      }

      const notesSection = document.createElement("section");
      notesSection.setAttribute("class", "notesgrid");
      notesSection.setAttribute("id", "notesSection");

      const ncDescTitle = document.createElement("h3");
      ncDescTitle.setAttribute("class", "header3");
      ncDescTitle.setAttribute("id", "trendTitle");

      const btnEditDesc = document.createElement("button");
      btnEditDesc.setAttribute("class", "btn");
      btnEditDesc.setAttribute("class", "btnEditNotes");
      btnEditDesc.setAttribute("id", "btnEditDesc");
      btnEditDesc.setAttribute("type", "submit");
      btnEditDesc.textContent = "Edit Desc.";

      const dispositionTitle = document.createElement("h3");
      dispositionTitle.setAttribute("class", "header3");

      const btnEditDisposition = document.createElement("button");
      btnEditDisposition.setAttribute("class", "btn");
      btnEditDisposition.setAttribute("class", "btnEditNotes");
      btnEditDisposition.setAttribute("id", "btnEditDisp");
      btnEditDisposition.textContent = "Edit Disp.";

      const verificationTitle = document.createElement("h3");
      verificationTitle.setAttribute("class", "header3");

      const btnEditVerf = document.createElement("button");
      btnEditVerf.setAttribute("class", "btn");
      btnEditVerf.setAttribute("class", "btnEditNotes");
      btnEditVerf.setAttribute("id", "btnEditVerf");
      btnEditVerf.textContent = "Edit Verf.";

      const notesTitle = document.createElement("h3");
      notesTitle.setAttribute("class", "header3");

      const btnEditNote = document.createElement("button");
      btnEditNote.setAttribute("class", "btn");
      btnEditNote.setAttribute("class", "btnEditNotes");
      btnEditNote.setAttribute("id", "btnEditNote");
      btnEditNote.textContent = "Edit Notes";

      const linebreak = document.createElement("br");

      elemRpt.textContent = "Nonconformance Detail";
      elemRpt.setAttribute("class", "header");

      // make a div for the subtitle and add the subtitle to the div and a button
      const divSubTitle = document.createElement("div");
      divSubTitle.setAttribute("class", "subtitlewithbutton");

      // Add title to the div
      elemId.textContent = "NCM Id: " + record[key]["NCM_ID"];
      elemId.setAttribute("class", "header2");
      elemId.setAttribute("id", "nid");
      divSubTitle.appendChild(elemId);

      // Add close button to the div
      const btnClose = document.createElement("button");
      btnClose.setAttribute("class", "closebutton");
      btnClose.textContent = "Close NCM";
      btnClose.setAttribute("id", "btnCloseNCM");
      btnClose.setAttribute("type", "submit");

      // disable the close button if already closed or if user is not TKENT
      if (record[key]["CLOSED"] === "Y") {
        btnClose.disabled = true;
        btnClose.style.opacity = "0.5";
        btnClose.style.cursor = "not-allowed";
        btnClose.style.backgroundColor = "#e0e0e0";
        btnClose.title = "This NCM is already closed";
      } else if (user === "TKENT") {
        btnClose.disabled = false;
      } else {
        btnClose.disabled = true;
      }

      // Create a buttons container for proper alignment
      const buttonsContainer = document.createElement("div");
      buttonsContainer.style.display = "flex";
      buttonsContainer.style.justifyContent = "flex-end";
      buttonsContainer.style.alignItems = "center";
      buttonsContainer.style.gap = "10px";

      // Add escalation button if overdue
      const daysOverdue = calculateDaysOverdue(record[key]["DUE_DATE"]);
      if (daysOverdue > 0 && record[key]["CLOSED"] !== "Y") {
        const escalationBtn = createEscalationButton(
          "NONCONFORMANCE",
          record[key]["NCM_ID"],
          record[key]["SUBJECT"],
          record[key]["ASSIGNED_TO"],
          daysOverdue,
          user,
          () => {
            // Refresh page on successful escalation
            location.reload();
          },
        );
        escalationBtn.style.display = "none"; // Hide escalation button for now
        buttonsContainer.appendChild(escalationBtn);
      }

      // Add close button to container
      buttonsContainer.appendChild(btnClose);
      divSubTitle.appendChild(buttonsContainer);

      const empty = document.createElement("p");

      detailSection.appendChild(detailHeading);
      detailSection.appendChild(divDetailBtns);
      detailSection.appendChild(empty);
      detailSection.appendChild(productId);
      detailSection.appendChild(ncmDate);
      detailSection.appendChild(caAssTo);
      detailSection.appendChild(aiClosedDate);
      detailSection.appendChild(reqBy);
      detailSection.appendChild(due_date);
      detailSection.appendChild(ncmType);
      detailSection.appendChild(subject);
      detailSection.appendChild(cause);
      detailSection.appendChild(lotNumber);
      detailSection.appendChild(lotQty);
      detailSection.appendChild(rmaId);
      detailSection.appendChild(po_number);

      const divDesc = document.createElement("div");
      divDesc.setAttribute("class", "notes");

      // Create a grid container for this section
      const descSectionGrid = document.createElement("div");
      descSectionGrid.setAttribute("class", "section-grid");

      // Create title text span
      const titleTextSpan = document.createElement("span");
      titleTextSpan.setAttribute("class", "title-text");
      titleTextSpan.textContent = "Description:";

      // Add all three elements to the grid: title, button, content
      descSectionGrid.appendChild(titleTextSpan);
      descSectionGrid.appendChild(btnEditDesc);
      descSectionGrid.appendChild(divDesc);

      divDesc.textContent = record[key]["DESCRIPTION"];
      divDesc.setAttribute("id", "inputtext");
      divDesc.innerHTML = divDesc.innerHTML.replace(/\n/g, "<br>");
      notesSection.appendChild(descSectionGrid);

      const divDisposition = document.createElement("div");
      divDisposition.setAttribute("class", "disposition");
      divDisposition.setAttribute("class", "notes");
      divDisposition.setAttribute("id", "disptext");

      // Create a grid container for this section
      const dispSectionGrid = document.createElement("div");
      dispSectionGrid.setAttribute("class", "section-grid");

      // Create title text span
      const dispTitleTextSpan = document.createElement("span");
      dispTitleTextSpan.setAttribute("class", "title-text");
      dispTitleTextSpan.textContent = "Disposition:";

      dispositionTitle.setAttribute("id", "dispTitle");
      if (
        record[key]["DISPOSITION"] === null ||
        record[key]["DISPOSITION"] === "" ||
        record[key]["DISPOSITION"] === undefined
      ) {
        divDisposition.innerHTML = "<br>";
      } else {
        divDisposition.textContent = record[key]["DISPOSITION"];
        divDisposition.innerHTML = divDisposition.innerHTML.replace(
          /\n/g,
          "<br>",
        );
      }

      // Add all three elements to the grid: title, button, content
      dispSectionGrid.appendChild(dispTitleTextSpan);
      dispSectionGrid.appendChild(btnEditDisposition);
      dispSectionGrid.appendChild(divDisposition);
      notesSection.appendChild(dispSectionGrid);

      const divVerification = document.createElement("div");
      divVerification.setAttribute("class", "verification");
      divVerification.setAttribute("class", "notes");
      divVerification.setAttribute("id", "verftext");

      // Create a grid container for this section
      const verfSectionGrid = document.createElement("div");
      verfSectionGrid.setAttribute("class", "section-grid");

      // Create title text span
      const verfTitleTextSpan = document.createElement("span");
      verfTitleTextSpan.setAttribute("class", "title-text");
      verfTitleTextSpan.textContent = "Verification:";

      verificationTitle.setAttribute("id", "verificationTitle");
      divVerification.innerHTML = divVerification.innerHTML.replace(
        /\n/g,
        "<br>",
      );
      if (
        record[key]["VERIFICATION"] === null ||
        record[key]["VERIFICATION"] === "" ||
        record[key]["VERIFICATION"] === undefined
      ) {
        divVerification.innerHTML = "<br>";
      } else {
        divVerification.textContent = record[key]["VERIFICATION"];
        divVerification.innerHTML = divVerification.innerHTML.replace(
          /\n/g,
          "<br>",
        );
      }

      // Add all three elements to the grid: title, button, content
      verfSectionGrid.appendChild(verfTitleTextSpan);
      verfSectionGrid.appendChild(btnEditVerf);
      verfSectionGrid.appendChild(divVerification);
      notesSection.appendChild(verfSectionGrid);

      const divNcmNotes = document.createElement("div");
      divNcmNotes.setAttribute("class", "ncmnotes");
      divNcmNotes.setAttribute("class", "notes");
      divNcmNotes.setAttribute("id", "notetext");

      // Create a grid container for this section
      const notesSectionGrid = document.createElement("div");
      notesSectionGrid.setAttribute("class", "section-grid");

      // Create title text span
      const notesTitleTextSpan = document.createElement("span");
      notesTitleTextSpan.setAttribute("class", "title-text");
      notesTitleTextSpan.textContent = "Notes:";

      notesTitle.setAttribute("id", "notesTitle");
      divNcmNotes.innerHTML = divNcmNotes.innerHTML.replace(/\n/g, "<br>");
      if (
        record[key]["NCM_NOTE"] === null ||
        record[key]["NCM_NOTE"] === "" ||
        record[key]["NCM_NOTE"] === undefined
      ) {
        divNcmNotes.innerHTML = "<br>";
      } else {
        divNcmNotes.textContent = record[key]["NCM_NOTE"];
        divNcmNotes.innerHTML = divNcmNotes.innerHTML.replace(/\n/g, "<br>");
      }

      // Add all three elements to the grid: title, button, content
      notesSectionGrid.appendChild(notesTitleTextSpan);
      notesSectionGrid.appendChild(btnEditNote);
      notesSectionGrid.appendChild(divNcmNotes);
      notesSection.appendChild(notesSectionGrid);

      main.appendChild(elemRpt);
      main.appendChild(divSubTitle);
      main.appendChild(detailSection);
      main.appendChild(notesSection);
    }

    // Setup event listeners after rendering
    setupNCMEventListeners();
  }

  // Function to setup all event listeners
  function setupNCMEventListeners() {
    // =============================================
    // Listen for the btnEditDesc button click
    const btnEditDesc = document.querySelector("#btnEditDesc");
    btnEditDesc.addEventListener("click", async (event) => {
      // prevent the default action
      event.preventDefault();
      // show the trend description dialog
      const trendDescriptionDialog = document.querySelector(
        "#trendDescriptionDialog",
      );
      trendDescriptionDialog.showModal();
    });

    // Listen for the btnEditDisposition button click
    const btnEditDisposition = document.querySelector("#btnEditDisp");
    btnEditDisposition.addEventListener("click", async (event) => {
      // prvent the default action
      event.preventDefault();
      // show the trend dialog
      const dispositionDialog = document.querySelector("#dispDialog");
      dispositionDialog.showModal();
    });

    // =============================================
    // Listen for the btnEditVerf button click
    const btnEditVerf = document.querySelector("#btnEditVerf");
    btnEditVerf.addEventListener("click", async (event) => {
      // prvent the default action
      event.preventDefault();
      // show the trend dialog
      const verfDialog = document.querySelector("#verfDialog");
      verfDialog.showModal();
    });

    // =============================================
    // Listen for the btnEditNote button click
    const btnEditNote = document.querySelector("#btnEditNote");
    btnEditNote.addEventListener("click", async (event) => {
      // prvent the default action
      event.preventDefault();
      // show the trend dialog
      const noteDialog = document.querySelector("#noteDialog");
      noteDialog.showModal();
    });

    // =============================================
    // Listen for the btnEditDetail button click
    const btnEditDetail = document.querySelector("#btnEditDetail");
    btnEditDetail.addEventListener("click", async (event) => {
      // prvent the default action
      event.preventDefault();
      // show the detail dialog
      const detailDialog = document.querySelector("#detailDialog");
      detailDialog.showModal();
    });

    // =============================================
    // Listen for the btnTrend button click
    const btnTrend = document.querySelector("#btnTrend");
    btnTrend.addEventListener("click", async (event) => {
      event.preventDefault();
      const trendDialog = document.querySelector("#trendDialog");

      const trendUrl = `${apiUrl}/trend/${iid}`;
      try {
        const response = await fetch(trendUrl);
        const trendData = await response.json();
        if (trendData.length > 0) {
          const data = trendData[0];
          document.getElementById("CUSTOMER_ID").value = data.CUSTOMER_ID || "";
          document.getElementById("SUPPLIER_ID").value = data.SUPPLIER_ID || "";
          document.getElementById("PROCESS_ID").value = data.PROCESS_ID || "";
          document.getElementById("AREA_NUMBER").value = data.AREA_NUMBER || "";
          document.getElementById("ACTIVITY_NO").value = data.ACTIVITY_NO || "";
          document.getElementById("ELEMENT_NO").value = data.ELEMENT_NO || "";
          document.getElementById("DISPOSITION_TYPE").value =
            data.DISPOSITION_TYPE || "";
          document.getElementById("TOOL_ID").value = data.TOOL_ID || "";
          document.getElementById("CORRECTIVE_ID").value =
            data.CORRECTIVE_ID || "";
        }
      } catch (error) {
        console.error("Error fetching trend data:", error);
      }
      trendDialog.showModal();
    });

    // =============================================
    // Listen for click on close dialog button class
    const closedialog = document.querySelectorAll(".closedialog");
    closedialog.forEach((element) => {
      element.addEventListener("click", async (event) => {
        // prevent the default action
        event.preventDefault();
        // close the dialog
        const dialog = element.closest("dialog");
        dialog.close();
      });
    });

    // // =============================================
    // // Listen for the saveNotes button class
    const saveNotes = document.querySelectorAll(".dialogSaveBtn");
    saveNotes.forEach((element) => {
      element.addEventListener("click", async (event) => {
        // prevent the default action
        event.preventDefault();
        // get the clicked button id
        // get the input id
        const nid = document.querySelector("#nid");
        let nidValue = iid;

        const fieldname = event.target.id;

        if (test) {
          console.log(fieldname);
          console.log(nidValue);
        }

        let data = {
          NCM_ID: nidValue,
        };
        // console.log(data);

        let compositetext = "";
        const d = new Date();
        const date = d.toISOString().substring(0, 10);
        const time = d.toLocaleTimeString();
        const mydate = date + " " + time;

        switch (fieldname) {
          case "saveTrendDesc":
            // console.log('input text');
            let previoustext = document.querySelector("#inputtext").innerHTML;
            let newtextTrendDesc =
              document.querySelector("#newtextTrendDesc").value;
            // if lenght of newtextTrendDesc is 0, do not save
            if (newtextTrendDesc.length === 0) {
              alert("Not saving, no trend text.");
              break;
            } else {
              let compositetext =
                user +
                " - " +
                mydate +
                "<br>" +
                document.querySelector("#newtextTrendDesc").value +
                "<br><br>" +
                previoustext;
              data = { ...data, DESCRIPTION: compositetext };
              data = { ...data, MY_TABLE: "NCM_DESCRIPTION" };
            }
            break;

          case "saveDisp":
            // console.log('followup text');
            let previoustext2 = document.querySelector("#disptext").innerHTML;
            let newtextDisp = document.querySelector("#newtextDisp").value;
            if (newtextDisp.length === 0) {
              alert("Not saving, no disposition text.");
              break;
            } else {
              let compositetext2 =
                user +
                " - " +
                mydate +
                "<br>" +
                document.querySelector("#newtextDisp").value +
                "<br><br>" +
                previoustext2;
              data = { ...data, DISPOSITION: compositetext2 };
              data = { ...data, MY_TABLE: "NCM_DISPOSITION" };
            }
            break;

          case "saveVerf":
            let previoustext3 = document.querySelector("#verftext").innerHTML;
            let newtextVerf = document.querySelector("#newtextVerf").value;
            if (newtextVerf.length === 0) {
              alert("Not saving, no verification text.");
              break;
            } else {
              let compositetext3 =
                user +
                " - " +
                mydate +
                "<br>" +
                document.querySelector("#newtextVerf").value +
                "<br><br>" +
                previoustext3;
              data = { ...data, VERIFICATION: compositetext3 };
              data = { ...data, MY_TABLE: "NCM_VERIFICATION" };
            }
            break;

          case "saveNote":
            let previoustext4 = document.querySelector("#notetext").innerHTML;
            let newtextNote = document.querySelector("#newtextNote").value;
            if (newtextNote.length === 0) {
              alert("Not saving, no note text.");
              break;
            } else {
              let compositetext4 =
                user +
                " - " +
                mydate +
                "<br>" +
                document.querySelector("#newtextNote").value +
                "<br><br>" +
                previoustext4;
              data = { ...data, NCM_NOTE: compositetext4 };
              data = { ...data, MY_TABLE: "NCM_NOTES" };
            }
            break;

          case "saveTrendDetail":
            const formData = new FormData(
              document.getElementById("edittrendform"),
            );
            const trendData = Object.fromEntries(formData.entries());
            data = { ...data, ...trendData };
            break;

          default:
            console.log("default");
        }

        if (test) {
          console.log(data);
        }

        let fetchUrl = url;
        if (fieldname === "saveTrendDetail") {
          fetchUrl = `${apiUrl}/trend/${iid}`;
        }

        const options = {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        };

        const response = await fetch(fetchUrl, options);

        if (!response.ok) {
          const errorText = await response.text();
          console.error("API Error:", response.status, errorText);
          alert(`Error saving: ${response.status} - ${errorText}`);
          return;
        }

        const json = await response.json();

        let dialogToClose;
        switch (fieldname) {
          case "saveTrendDesc":
            dialogToClose = document.querySelector("#trendDescriptionDialog");
            break;
          case "saveTrendDetail":
            dialogToClose = document.querySelector("#trendDialog");
            break;
          case "saveDisp":
            dialogToClose = document.querySelector("#dispDialog");
            break;
          case "saveVerf":
            dialogToClose = document.querySelector("#verfDialog");
            break;
          case "saveNote":
            dialogToClose = document.querySelector("#noteDialog");
            break;
          default:
            dialogToClose = document.querySelector("#trendDialog");
        }
        if (dialogToClose) dialogToClose.close();

        // refresh the data via AJAX
        await refreshNCMData();
      });
    });

    // =============================================
    // Listen for the editDetail button
    const editDetail = document.querySelector("#btnEditDetail");
    editDetail.addEventListener("click", async (event) => {
      const detailDialog = document.querySelector("#detailDialog");
      const editdetailform = document.querySelector("#editdetailform");
      // prevent the default action
      event.preventDefault();

      // Clear previous form content
      editdetailform.innerHTML = "";

      // Define fields and their types
      const fields = [
        { name: "PEOPLE_ID", label: "Request By", type: "text" },
        { name: "NCM_DATE", label: "Request Date", type: "date" },
        { name: "ASSIGNED_TO", label: "Assigned To", type: "text" },
        { name: "DUE_DATE", label: "Due Date", type: "date" },
        { name: "NCM_TYPE", label: "Type", type: "text" },
        { name: "SUBJECT", label: "Subject", type: "select" },
        { name: "CAUSE", label: "Cause", type: "select" },
        { name: "PRODUCT_ID", label: "Product Id", type: "text" },
        { name: "LOT_NUMBER", label: "Lot Number", type: "text" },
        { name: "LOT_SIZE", label: "Lot Qty", type: "text" },
        { name: "USER_DEFINED_1", label: "RMA Id", type: "text" },
        { name: "CUSTOMER_ID", label: "Customer Id", type: "text" },
        { name: "SUPPLIER_ID", label: "Supplier Id", type: "text" },
      ];

      // Fetch subjects and causes for dropdowns
      const subjects = await fetchSubjects();
      const causes = await fetchCauses();

      // Get current record (first key)
      const recKey = Object.keys(record)[0];
      const rec = record[recKey] || {};

      fields.forEach((field) => {
        const fieldWrapper = document.createElement("div");
        fieldWrapper.className = "formFieldWrapper";
        const label = document.createElement("label");
        label.htmlFor = field.name;
        label.textContent = field.label + ": ";
        fieldWrapper.appendChild(label);

        let input;
        if (field.type === "select") {
          input = document.createElement("select");
          input.id = field.name;
          input.name = field.name;
          // Add default empty option
          const defaultOpt = document.createElement("option");
          defaultOpt.value = "";
          defaultOpt.textContent = "--Select--";
          input.appendChild(defaultOpt);
          if (field.name === "SUBJECT") {
            subjects.forEach((subject) => {
              const option = document.createElement("option");
              option.value = subject.SUBJECT;
              option.textContent = `${subject.SUBJECT} - ${subject.DESCRIPTION}`;
              input.appendChild(option);
            });
          } else if (field.name === "CAUSE") {
            causes.forEach((cause) => {
              const option = document.createElement("option");
              option.value = cause.CAUSE;
              option.textContent = `${cause.CAUSE} - ${cause.DESCRIPTION}`;
              input.appendChild(option);
            });
          }
        } else {
          input = document.createElement("input");
          input.type = field.type;
          input.id = field.name;
          input.name = field.name;
        }

        // Set value from record
        if (rec[field.name] !== undefined && rec[field.name] !== null) {
          if (field.type === "date" && rec[field.name]) {
            input.value = rec[field.name].substring(0, 10);
          } else {
            input.value = rec[field.name];
          }
        }
        fieldWrapper.appendChild(input);
        editdetailform.appendChild(fieldWrapper);
      });

      // Add Save and Cancel buttons
      const saveBtn = document.createElement("button");
      saveBtn.type = "button";
      saveBtn.id = "saveDetail";
      saveBtn.className = "btnDialog dialogSaveBtn";
      saveBtn.textContent = "Save";
      editdetailform.appendChild(saveBtn);

      const cancelBtn = document.createElement("button");
      cancelBtn.type = "button";
      cancelBtn.id = "btnCancelDetail";
      cancelBtn.className = "btnDialog";
      cancelBtn.textContent = "Cancel";
      editdetailform.appendChild(cancelBtn);

      // show the detail dialog
      detailDialog.showModal();

      // Listen for the saveDetail button click
      const saveDetail = document.querySelector("#saveDetail");
      const detailsUrl = `${apiUrl}/ncm/details/${iid}`;
      saveDetail.addEventListener("click", async (event) => {
        event.preventDefault();
        const nid = document.querySelector("#nid");
        let nidValue = iid;

        let data = {
          NCM_ID: nidValue,
          MODIFIED_BY: user,
          MODIFIED_DATE: getDateTime(),
        };

        const fields = [
          "PEOPLE_ID",
          "NCM_DATE",
          "ASSIGNED_TO",
          "DUE_DATE",
          "NCM_TYPE",
          "SUBJECT",
          "CAUSE",
          "PRODUCT_ID",
          "LOT_NUMBER",
          "LOT_SIZE",
          "USER_DEFINED_1",
          "CUSTOMER_ID",
          "SUPPLIER_ID",
        ];

        fields.forEach((fieldName) => {
          try {
            const fieldElement = document.querySelector("#" + fieldName);
            let fieldvalue = fieldElement ? fieldElement.value : "";
            if (fieldvalue === undefined) {
              fieldvalue = "";
            }
            data[fieldName] = fieldvalue;
          } catch (error) {
            data[fieldName] = "";
          }
        });

        // Validate username fields
        if (data.PEOPLE_ID) {
          const peopleIdValidation = validateUsernameField(
            "request-by",
            data.PEOPLE_ID,
          );
          if (!peopleIdValidation.isValid) {
            alert(peopleIdValidation.message);
            return;
          }
        }

        if (data.ASSIGNED_TO) {
          const assignedToValidation = validateUsernameField(
            "assigned-to",
            data.ASSIGNED_TO,
          );
          if (!assignedToValidation.isValid) {
            alert(assignedToValidation.message);
            return;
          }
        }

        // Validate code fields
        if (data.NCM_TYPE) {
          const typeValidation = validateCodeField("type", data.NCM_TYPE);
          if (!typeValidation.isValid) {
            alert(typeValidation.message);
            return;
          }
        }

        if (data.SUBJECT) {
          const subjectValidation = validateCodeField("subject", data.SUBJECT);
          if (!subjectValidation.isValid) {
            alert(subjectValidation.message);
            return;
          }
        }

        if (data.CAUSE) {
          const causeValidation = validateCodeField("cause", data.CAUSE);
          if (!causeValidation.isValid) {
            alert(causeValidation.message);
            return;
          }
        }

        // Subject length validation
        if (data.SUBJECT && data.SUBJECT.length > 6) {
          alert(
            "Subject must be 6 characters or less. Please see the help file for valid codes.",
          );
          window.open("/ncmhelp.html", "_blank");
          const subjectNcm = document.querySelector("#SUBJECT");
          if (subjectNcm) subjectNcm.focus();
          return;
        }

        if (test) {
          console.log("=== SAVE DETAIL DATA ===");
          console.log(data);
          console.log("CAUSE field value:", data.CAUSE);
        }

        const options = {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        };

        const response = await fetch(detailsUrl, options);

        if (!response.ok) {
          const errorText = await response.text();
          console.error("API Error:", response.status, errorText);
          alert(`Error saving: ${response.status} - ${errorText}`);
          return;
        }

        const json = await response.json();
        detailDialog.close();
        // refresh the data via AJAX
        await refreshNCMData();
      });

      // =============================================
      // Listen for the close button click
      const closebutton = document.querySelector("#btnCancelDetail");
      closebutton.addEventListener("click", async (event) => {
        // prevent the default action
        event.preventDefault();
        // close the detailDialog
        const detailDialog = document.querySelector("#detailDialog");
        detailDialog.close();
      });
    });

    // =============================================
    // Listen for the close NCM button click
    const closeNCM = document.querySelector("#btnCloseNCM");
    closeNCM.addEventListener("click", async (event) => {
      // prevent the default action
      event.preventDefault();
      // if the user is not TKENT, do not allow the close
      if (user !== "TKENT") {
        alert("Only TKENT can close the NCM");
        return;
      }
      const closeUrl = `${apiUrl}/ncm/close/${iid}`;

      let data = {
        NCM_ID: iid,
        CLOSED: "Y",
        CLOSED_DATE: new Date().toISOString(),
      };

      if (test) {
        console.log(data);
      }

      const options = {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      };

      const response = await fetch(closeUrl, options);

      if (!response.ok) {
        const errorText = await response.text();
        console.error("API Error:", response.status, errorText);
        alert(`Error closing NCM: ${response.status} - ${errorText}`);
        return;
      }

      const json = await response.json();

      // Disable and grey out the button
      closeNCM.disabled = true;
      closeNCM.style.opacity = "0.5";
      closeNCM.style.cursor = "not-allowed";
      closeNCM.style.backgroundColor = "#e0e0e0";

      // refresh the data via AJAX
      await refreshNCMData();
    });
  }
}

// Initialize the page
refreshNCMData();
