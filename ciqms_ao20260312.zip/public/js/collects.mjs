import { loadHeaderFooter, getApiUrl, getSessionUser } from "./utils.mjs";

loadHeaderFooter();

let collectUrl = "";

// Helper function to format ID with zero-padding to 7 digits
function formatIdForDisplay(id) {
  if (id === null || id === undefined) return "";
  return String(id).padStart(7, "0");
}

// Resizable columns functions
function getCollectsColumnWidths() {
  try {
    const widths = localStorage.getItem("collects_column_widths");
    return widths ? JSON.parse(widths) : null;
  } catch (error) {
    console.error("Error retrieving column widths:", error);
    return null;
  }
}

function saveCollectsColumnWidths(widths) {
  try {
    localStorage.setItem("collects_column_widths", JSON.stringify(widths));
  } catch (error) {
    console.error("Error saving column widths:", error);
  }
}

function initializeCollectsColumnResizing(table) {
  const headers = table.querySelectorAll("thead th");
  const colgroup = table.querySelector("colgroup");
  if (!colgroup) return;

  const cols = colgroup.querySelectorAll("col");

  headers.forEach((header, index) => {
    // Create resize handle
    const resizeHandle = document.createElement("div");
    resizeHandle.className = "column-resize-handle";
    resizeHandle.style.position = "absolute";
    resizeHandle.style.right = "0";
    resizeHandle.style.top = "0";
    resizeHandle.style.height = "100%";
    resizeHandle.style.width = "4px";
    resizeHandle.style.backgroundColor = "rgba(200, 200, 200, 0.5)";
    resizeHandle.style.borderRight = "1px solid #999";
    resizeHandle.style.cursor = "col-resize";
    resizeHandle.style.userSelect = "none";

    header.appendChild(resizeHandle);

    // Set up resize logic
    resizeHandle.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();

      const startX = e.clientX;
      const currentCol = cols[index];
      const currentWidth = currentCol.offsetWidth;

      const onMouseMove = (moveEvent) => {
        const diff = moveEvent.clientX - startX;
        const newWidth = Math.max(50, currentWidth + diff);
        currentCol.style.width = newWidth + "px";
      };

      const onMouseUp = () => {
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
        resizeHandle.style.backgroundColor = "rgba(200, 200, 200, 0.5)";

        // Save the new widths to localStorage
        const widths = Array.from(cols).map((col) => col.style.width || "auto");
        saveCollectsColumnWidths(widths);
      };

      resizeHandle.style.backgroundColor = "rgba(100, 150, 255, 0.9)";
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    });

    // Show handle more prominently on hover
    resizeHandle.addEventListener("mouseenter", () => {
      resizeHandle.style.backgroundColor = "rgba(100, 150, 255, 0.9)";
      resizeHandle.style.borderRight = "1px solid #0066ff";
    });

    resizeHandle.addEventListener("mouseleave", () => {
      resizeHandle.style.backgroundColor = "rgba(200, 200, 200, 0.5)";
      resizeHandle.style.borderRight = "1px solid #999";
    });
  });
}

// Helper function to map field names to display column aliases
function getDisplayName(field) {
  const aliases = {
    PRODUCT_COLLECT_ID: "COLLECT ID",
    PRD_INSP_PLN_SYSID: "PLAN ID",
    OPERATION_NO: "OP",
    COLLECTION_DATE: "COLL DATE",
    PLAN_REV_LEVEL: "PLN REV",
    DUE_DATE: "DUE DATE",
    PO_NUMBER: "PO NUMBER",
    LOT_NUMBER: "LOT NUMBER",
    LOT_SIZE: "LOT SIZE",
    ASSIGNED_TO: "ASSIGNED TO",
    PRODUCT_REV_LEVEL: "PRODUCT REV LEVEL",
    PRODUCT_ID: "PRODUCT ID",
    ACCEPTED: "ACC",
    REJECTED: "REJ",
    NCM_ID: "NCM ID",
    LOT_SYSID: "LOT SYSID",
  };
  return aliases[field] || field.replace(/_/g, " ");
}

// Wait for DOM and fetch API URL before anything else
document.addEventListener("DOMContentLoaded", async () => {
  const apiUrl = await getApiUrl();
  collectUrl = `${apiUrl}/collect/prod-plan-data`;

  console.log("[collects.mjs] Initialized URL:", collectUrl);

  const user = await getSessionUser();
  const prodPlanContainer = document.getElementById("prod-plan-container");
  const columnControls = document.getElementById("column-controls");
  const createProductPlanDialog = document.querySelector(
    "[create-product-plan-dialog]",
  );

  // Setup ASSIGNED_TO field validation: no spaces, uppercase
  const assignedToField = document.getElementById("assigned-to");
  if (assignedToField) {
    assignedToField.addEventListener("input", (e) => {
      let value = e.target.value;
      const originalValue = value;

      // Remove spaces and convert to uppercase
      value = value.replace(/\s+/g, "").toUpperCase();

      // If spaces were removed, warn the user
      if (value !== originalValue.toUpperCase()) {
        alert(
          "User IDs cannot contain spaces. Please use a valid userid (no spaces).",
        );
      }

      e.target.value = value;
    });
  }

  // read the id from the URL
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get("id");

  const createPlanHeader = document.querySelector("#create-plan-header");
  if (createPlanHeader) {
    if (id) {
      createPlanHeader.innerHTML = "Create Collect for Product: " + id;
    } else {
      createPlanHeader.innerHTML = "Create Collect";
    }
  }

  // Create and add the Add Collect button to column controls
  if (columnControls) {
    const addCollBtn = document.createElement("button");
    addCollBtn.type = "submit";
    addCollBtn.classList.add("btn", "btn-plus");
    addCollBtn.id = "btnAddColl";
    addCollBtn.textContent = "+ Add Collect";
    addCollBtn.setAttribute("title", "Click to add a new collect");

    addCollBtn.addEventListener("click", (e) => {
      e.preventDefault();
      const productIdField = document.getElementById("product-id");
      const collectionDateField = document.getElementById("collection-date");
      const dueDateField = document.getElementById("due-date");

      // If we have a product ID from the URL, pre-populate the field
      if (id && productIdField) {
        productIdField.value = id;
      }

      // Set Collection Date to today
      if (collectionDateField) {
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, "0");
        const dd = String(today.getDate()).padStart(2, "0");
        collectionDateField.value = `${yyyy}-${mm}-${dd}`;
      }

      // Set Due Date to tomorrow (today + 1 day)
      if (dueDateField) {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const yyyy = tomorrow.getFullYear();
        const mm = String(tomorrow.getMonth() + 1).padStart(2, "0");
        const dd = String(tomorrow.getDate()).padStart(2, "0");
        dueDateField.value = `${yyyy}-${mm}-${dd}`;
      }

      if (createProductPlanDialog) {
        createProductPlanDialog.showModal();
      }
    });

    columnControls.appendChild(addCollBtn);
  }

  function displayNewRecord(record) {
    // Get the existing table or create a new one if needed
    const existingTable = prodPlanContainer.querySelector("table");

    if (!existingTable) {
      // No table exists yet, just refresh
      return;
    }

    // Get the tbody of existing table
    const tbody = existingTable.querySelector("tbody");
    if (!tbody) {
      return;
    }

    // Get the headers from existing table to determine which fields to display
    const headers = existingTable.querySelectorAll("thead th");
    const fields = Array.from(headers).map((th) => {
      const text = th.textContent.toUpperCase();
      // Map display names back to field names
      if (text === "COLL DATE") return "COLLECTION_DATE";
      if (text === "COLLECT ID") return "PRODUCT_COLLECT_ID";
      if (text === "PLAN ID") return "PRD_INSP_PLN_SYSID";
      if (text === "OP") return "OPERATION_NO";
      if (text === "PLN REV") return "PLAN_REV_LEVEL";
      if (text === "DUE DATE") return "DUE_DATE";
      if (text === "PRODUCT REV LEVEL") return "PRODUCT_REV_LEVEL";
      if (text === "PO NUMBER") return "PO_NUMBER";
      if (text === "LOT NUMBER") return "LOT_NUMBER";
      if (text === "LOT SIZE") return "LOT_SIZE";
      if (text === "ASSIGNED TO") return "ASSIGNED_TO";
      return text.replace(/ /g, "_");
    });

    // Create a new row
    const row = document.createElement("tr");
    fields.forEach((field) => {
      const td = document.createElement("td");
      const val = record[field];

      if (val === null || val === undefined) {
        td.textContent = "";
      } else if (field === "PRODUCT_COLLECT_ID") {
        // Format ID with zero-padding
        td.textContent = formatIdForDisplay(val);
      } else if (field.toLowerCase().endsWith("date") && record[field]) {
        const date = new Date(record[field]);
        if (!isNaN(date)) {
          td.textContent = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
        } else {
          td.textContent = String(val);
        }
      } else {
        td.textContent = String(val || "");
      }
      row.appendChild(td);
    });

    // Insert at the top of tbody (most recent first)
    tbody.insertBefore(row, tbody.firstChild);
  }

  function getRecords() {
    // Clear only the table container
    if (prodPlanContainer) {
      prodPlanContainer.innerHTML = "";
    }

    // Determine the URL to fetch from based on whether we have an id
    const fetchUrl = id ? `${collectUrl}/${id}` : collectUrl;
    console.log(
      "[collects.mjs] Fetching from URL:",
      fetchUrl,
      "(collectUrl:",
      collectUrl,
      ", id:",
      id,
      ")",
    );

    fetch(fetchUrl, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        console.log(
          "[collects.mjs] Response status:",
          response.status,
          response.statusText,
        );
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
      })
      .then((data) => {
        // Validate that data is an array
        if (!Array.isArray(data)) {
          console.error("Expected array from API, got:", typeof data, data);
          data = [];
        }

        const displayData = data;

        // Specify which fields to display in the table
        let myFields = [
          "PRODUCT_COLLECT_ID",
          "PRD_INSP_PLN_SYSID",
          "PRODUCT_ID",
          "OPERATION_NO",
          "COLLECTION_DATE",
          "PO_NUMBER",
          "LOT_NUMBER",
          "LOT_SIZE",
          "ACCEPTED",
          "REJECTED",
          "ASSIGNED_TO",
          "PLAN_REV_LEVEL",
          "NCM_ID",
          "LOT_SYSID",
        ];

        // Check if there are no records
        if (displayData.length === 0) {
          const noRecordsDiv = document.createElement("div");
          noRecordsDiv.style.textAlign = "center";
          noRecordsDiv.style.padding = "40px 20px";
          noRecordsDiv.style.fontSize = "16px";
          noRecordsDiv.style.color = "#666";
          noRecordsDiv.textContent = "No collection records found";
          prodPlanContainer.appendChild(noRecordsDiv);
          return;
        }

        // Create a scrollable container for the table
        let tableContainer = document.createElement("div");
        tableContainer.className = "table-container";
        tableContainer.style.width = "100%"; // Full width
        tableContainer.style.flex = "1"; // Flex to fill available space
        tableContainer.style.overflowY = "auto"; // Enable vertical scrolling
        tableContainer.style.overflowX = "auto"; // Enable horizontal scrolling
        tableContainer.style.border = "1px solid #ddd"; // Border
        tableContainer.style.borderRadius = "4px"; // Rounded corners
        tableContainer.style.marginTop = "2px"; // Top margin
        tableContainer.style.marginBottom = "2px"; // Bottom margin

        let table = document.createElement("table");
        table.className = "table table-striped table-bordered table-hover";
        table.style.marginBottom = "0"; // Remove default table margin
        table.style.color = "#333"; // Ensure text color is visible
        table.style.backgroundColor = "#fff"; // Ensure background is visible
        table.id = "collectsTable";

        // Create colgroup with resizable column support
        const colgroup = document.createElement("colgroup");
        const savedWidths = getCollectsColumnWidths();
        myFields.forEach((field, index) => {
          const col = document.createElement("col");
          if (savedWidths && savedWidths[index]) {
            col.style.width = savedWidths[index];
          } else {
            col.style.width = "auto";
          }
          colgroup.appendChild(col);
        });
        table.appendChild(colgroup);

        // Create table header
        let thead = document.createElement("thead");
        thead.style.position = "sticky"; // Make header sticky
        thead.style.top = "0"; // Stick to top of container
        thead.style.backgroundColor = "#f8f9fa"; // Light background for header
        thead.style.zIndex = "10"; // Ensure header stays on top

        let headerRow = document.createElement("tr");
        myFields.forEach((field, index) => {
          let th = document.createElement("th");
          th.style.position = "relative";
          th.style.color = "#000"; // Ensure header text is visible
          th.style.backgroundColor = "#f8f9fa"; // Light background for header
          th.style.padding = "10px 8px"; // Padding
          th.style.borderBottom = "2px solid #ddd"; // Bottom border
          th.style.fontWeight = "bold"; // Bold text
          th.dataset.columnIndex = index;

          // Create wrapper for header text
          const headerText = document.createElement("span");
          headerText.style.display = "inline-block";
          headerText.style.userSelect = "none";
          headerText.textContent = getDisplayName(field);
          th.appendChild(headerText);

          headerRow.appendChild(th);
        });
        thead.appendChild(headerRow);
        table.appendChild(thead);

        // Create table body
        let tbody = document.createElement("tbody");
        displayData.forEach((record) => {
          let row = document.createElement("tr");
          myFields.forEach((field) => {
            let td = document.createElement("td");
            td.style.color = "#000"; // Ensure text is visible
            td.style.padding = "8px"; // Ensure spacing
            const val = record[field];

            // Handle PRD_INSP_PLN_SYSID first (before null check)
            if (field === "PRD_INSP_PLN_SYSID") {
              if (val === null || val === undefined || val === "") {
                td.textContent = "NO PLAN";
                td.style.color = "red";
                td.style.fontWeight = "bold";
              } else {
                td.textContent = formatIdForDisplay(val);
              }
            } else if (val === null || val === undefined) {
              td.textContent = "";
            } else if (
              typeof val === "string" &&
              (val === "I" || val === "P")
            ) {
              td.textContent = val === "I" ? "Internal" : "Passed";
            } else if (field === "PRODUCT_COLLECT_ID") {
              // Format ID fields with zero-padding to 7 digits
              td.textContent = formatIdForDisplay(val);
            } else if (field.toLowerCase().endsWith("date") && record[field]) {
              const date = new Date(record[field]);
              if (!isNaN(date)) {
                td.textContent = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
              } else {
                td.textContent = String(val);
              }
            } else {
              td.textContent = String(val || "");
            }
            row.appendChild(td);
          });
          tbody.appendChild(row);
        });
        table.appendChild(tbody);

        // Append the table to the container, then container to the prod plan element
        tableContainer.appendChild(table);
        prodPlanContainer.appendChild(tableContainer);

        // Initialize resizable columns
        initializeCollectsColumnResizing(table);
      })
      .catch((error) => {
        console.error("Error fetching records:", error);
        const errorDiv = document.createElement("div");
        errorDiv.style.textAlign = "center";
        errorDiv.style.padding = "40px 20px";
        errorDiv.style.fontSize = "16px";
        errorDiv.style.color = "#d00";
        errorDiv.innerHTML = `<strong>Error loading records:</strong><br>
        ${error.message}<br>
        <small style="color: #999;">Check browser console for details</small>`;
        prodPlanContainer.appendChild(errorDiv);
      });
  }

  // Listen for the cancel button
  const cancelAddProductPlan = document.getElementById(
    "cancel-add-product-plan",
  );
  if (cancelAddProductPlan) {
    cancelAddProductPlan.addEventListener("click", (e) => {
      e.preventDefault();
      if (createProductPlanDialog) {
        createProductPlanDialog.close();
      }
    });
  }

  const submitFormAddProductPlan = document.querySelector(
    "#buttonAddProductPlan",
  );
  if (submitFormAddProductPlan) {
    submitFormAddProductPlan.addEventListener("click", async (e) => {
      e.preventDefault();

      const myForm = document.querySelector("#create-product-plan-form");
      if (!myForm) {
        console.error("Form with id 'create-product-plan-form' not found.");
        return;
      }
      const formData = new FormData(myForm);
      const data = Object.fromEntries(formData.entries());

      // Validate required fields
      if (!data.PRODUCT_ID || !data.PRODUCT_REV_LEVEL || !data.OPERATION_NO) {
        alert("Product ID, Product Rev Level, and Operation No are required.");
        return;
      }

      // Validate ASSIGNED_TO field - no spaces allowed
      if (data.ASSIGNED_TO && data.ASSIGNED_TO.includes(" ")) {
        alert(
          "User IDs cannot contain spaces. Please use a valid userid (no spaces).",
        );
        return;
      }

      // Check if PRODUCT_INSP_PLAN exists with matching PRODUCT_ID, PRODUCT_REV_LEVEL, and OPERATION_NO
      try {
        const inspPlanResponse = await fetch(
          `${apiUrl}/collect/insp-plan/${data.PRODUCT_ID}/${data.PRODUCT_REV_LEVEL}/${data.OPERATION_NO}`,
        );

        if (!inspPlanResponse.ok) {
          const proceedAnyway = confirm(
            `No matching Inspection Plan found for:\n\nProduct ID: ${data.PRODUCT_ID}\nProduct Rev Level: ${data.PRODUCT_REV_LEVEL}\nOperation No: ${data.OPERATION_NO}\n\nDo you want to save anyway?`,
          );
          if (!proceedAnyway) {
            return;
          }
        } else {
          const inspPlanData = await inspPlanResponse.json();
          if (!inspPlanData || inspPlanData.length === 0) {
            const proceedAnyway = confirm(
              `No matching Inspection Plan found for:\n\nProduct ID: ${data.PRODUCT_ID}\nProduct Rev Level: ${data.PRODUCT_REV_LEVEL}\nOperation No: ${data.OPERATION_NO}\n\nDo you want to save anyway?`,
            );
            if (!proceedAnyway) {
              return;
            }
          }
        }
      } catch (error) {
        console.error("Error checking for inspection plan:", error);
        const proceedAnyway = confirm(
          `Error validating inspection plan. Do you want to save anyway?`,
        );
        if (!proceedAnyway) {
          return;
        }
      }

      data["CREATE_BY"] = user;
      const now = new Date();
      const mysqlDate = now.toISOString().slice(0, 19).replace("T", " ");
      data["CREATE_DATE"] = mysqlDate;

      // Uppercase fields
      if (data["PRODUCT_ID"]) {
        data["PRODUCT_ID"] = data["PRODUCT_ID"].toUpperCase();
      }
      if (data["PRODUCT_REV_LEVEL"]) {
        data["PRODUCT_REV_LEVEL"] = data["PRODUCT_REV_LEVEL"].toUpperCase();
      }
      if (data["LOT_NUMBER"]) {
        data["LOT_NUMBER"] = data["LOT_NUMBER"].toUpperCase();
      }
      if (data["OPERATION_NO"]) {
        data["OPERATION_NO"] = data["OPERATION_NO"].toUpperCase();
      }
      if (data["ASSIGNED_TO"]) {
        data["ASSIGNED_TO"] = data["ASSIGNED_TO"].toUpperCase();
      }

      // Ensure numeric fields are integers
      if (data["LOT_SIZE"]) {
        data["LOT_SIZE"] = parseInt(data["LOT_SIZE"], 10);
      }
      if (data["ACCEPTED"]) {
        data["ACCEPTED"] = parseInt(data["ACCEPTED"], 10);
      }
      if (data["REJECTED"]) {
        data["REJECTED"] = parseInt(data["REJECTED"], 10);
      }

      // Send the data to the server
      fetch(collectUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
        .then((response) => response.json())
        .then((result) => {
          if (result.success && result.record) {
            // Close the dialog
            if (createProductPlanDialog) {
              createProductPlanDialog.close();
            }

            // Clear the form for next entry
            myForm.reset();

            // Immediately add the new record to the table display
            displayNewRecord(result.record);

            // Refresh all records from server
            getRecords();
          } else {
            console.error("Error creating record:", result);
            alert("Error saving record. Please try again.");
          }
        })
        .catch((error) => {
          console.error("Error creating record:", error);
          alert("Error saving record: " + error.message);
        });
    });
  }

  // Load records when page loads
  getRecords();
});
